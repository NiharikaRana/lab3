// Require dotenv to load environment variables from .env file
require("dotenv").config({ path: 'configs/.env' });


module.exports = {
  ConnectionStrings: {
    MongoDB: process.env.MONGODB_URI,
  },
  Authentication: {
    Google: {
      ClientId: process.env.GOOGLE_CLIENT_ID,
      ClientSecret: process.env.GOOGLE_CLIENT_SECRET,
      CallbackURL: process.env.GOOGLE_CALLBACK_URL || "http://localhost:3000/google/callback",
    },
  },
};
