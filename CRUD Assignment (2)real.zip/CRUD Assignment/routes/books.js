
// Import express and create router object
const express = require("express");
const router = express.Router();
// Import mongoose model to be used
const Book = require("../models/book");
const Author = require("../models/author");

const AuthenticationMiddleware = require("../extensions/authentication");
router.get("/", async (req, res, next) => {
  // retrieve ALL data, and sort by dueDate
  let books = await Book.find().sort([["title", "descending"]]);
  // render view
  res.render("books/index", {
    title: "Books Tracker",
    dataset: books,
    user: req.user,
  });
});
// GET /projects/add
router.get("/add", AuthenticationMiddleware, async (req, res, next) => {
  let authorList = await Author.find().sort([["author", "ascending"]]);
  res.render("books/add", {
    title: "Add a New Book",
    authors: authorList,
    user: req.user,
  });
});

// POST /projects/add
router.post("/add", AuthenticationMiddleware, async (req, res, next) => {
  // use the project module to save data to DB
  // use the new Project() method of the model
  // and map the fields with data from the request
 
  let newBook = new Book({
    title: req.body.title,
    author: req.body.author,
    status: req.body.status
  });
  await newBook.save();
  res.redirect("/books");
});

// GET /projects/delete/_id
// access parameters via req.params object
router.get("/delete/:_id", AuthenticationMiddleware, async (req, res, next) => {
  let bookId = req.params._id;
  await Book.findByIdAndRemove({ _id: bookId });
  res.redirect("/books");
});

// GET /projects/edit/_id
router.get("/edit/:_id", AuthenticationMiddleware, async (req, res, next) => {
  let bookId = req.params._id;
  let authorList = await Author.find().sort([["author", "ascending"]]);
  res.render("books/edit", {
    title: "Edit Book Info",
    authors: authorList,
    user: req.user,
  });
});

// POST /projects/edit/_id
router.post("/edit/:_id", AuthenticationMiddleware, async (req, res, next) => {
  let bookId = req.params._id;
  await Book.findByIdAndUpdate(
    { _id: bookId }, // filter to find the project to update
    {
      // updated data
      title: req.body.title,
      author: req.body.author,
      status: req.body.status,
    }
  );
  res.redirect("/books");
});

// Export router object
module.exports = router;